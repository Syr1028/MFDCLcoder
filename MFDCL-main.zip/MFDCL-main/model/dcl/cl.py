import numpy as np
import torch

class CL(torch.nn.Module):
    def __init__(self, data):
        super(CL, self).__init__()
        self.dev = data.dev
        self.r = data.R

    def calculate_loss(self, x, y, masks_x, masks_y):

        cl_loss = self.sim_loss(x, masks_x, y, masks_y, self.r)

        return cl_loss

    def sim_loss(self, x, word_masks, y, img_masks, temperature):
        batch_size = x.size(0)

        out_1 = AvgPoolSequence(word_masks, x)
        out_2 = AvgPoolSequence(img_masks, y)

        pos_sim = torch.exp(torch.sum(out_1 * out_2, dim=-1) / temperature)
        pos_sim = torch.cat([pos_sim, pos_sim], dim=0)

        out = torch.cat([out_1, out_2], dim=0)
        sim_matrix = torch.exp(torch.mm(out, out.t().contiguous()) / temperature)
        mask = (torch.ones_like(sim_matrix) - torch.eye(2 * batch_size, device=sim_matrix.device)).byte()

        sim_matrix = sim_matrix.masked_select(mask).view(2 * batch_size, -1)

        loss = (- torch.log(pos_sim / sim_matrix.sum(dim=-1))).mean()
        return loss


class DCL(torch.nn.Module):
    def __init__(self, data):
        super(DCL, self).__init__()
        self.device = data.dev
        self.r = data.R
        self.debiased = True

    def calculate_loss(self, x, y, masks_x, masks_y):

        cl_loss = self.sim_loss(x, masks_x, y, masks_y, self.r)

        return cl_loss

    def get_negative_mask(self, batch_size):
        negative_mask = torch.ones((batch_size, 2 * batch_size)).byte()
        for i in range(batch_size):
            negative_mask[i, i] = 0
            negative_mask[i, i + batch_size] = 0

        negative_mask = torch.cat((negative_mask, negative_mask), 0)
        return negative_mask

    def sim_loss(self, x, word_masks, y, img_masks, temperature):
        tau_plus = 0.1
        batch_size = x.size(0)

        out_1 = AvgPoolSequence(word_masks, x)
        out_2 = AvgPoolSequence(img_masks, y)

        out = torch.cat([out_1, out_2], dim=0)
        neg = torch.exp(torch.mm(out, out.t().contiguous()) / temperature)
        mask = self.get_negative_mask(batch_size).cuda()
        neg = neg.masked_select(mask).view(2 * batch_size, -1)

        pos = torch.exp(torch.sum(out_1 * out_2, dim=-1) / temperature)
        pos = torch.cat([pos, pos], dim=0)

        if self.debiased:
            N = batch_size * 2 - 2
            Ng = (-tau_plus * N * pos + neg.sum(dim = -1)) / (1 - tau_plus)
            Ng = torch.clamp(Ng, min = N * np.e**(-1 / temperature))
        else:
            Ng = neg.sum(dim=-1)

        loss = (- torch.log(pos / (pos + Ng) )).mean()

        return loss

def AvgPoolSequence(attn_mask, feats, e=1e-12):
    """ The function will average pool the input features 'feats' in
        the second to rightmost dimension, taking into account
        the provided mask 'attn_mask'.
    Inputs:
        attn_mask (torch.Tensor): [batch_size, ...x(N), 1] Mask indicating
                                  relevant (1) and padded (0) positions.
        feats (torch.Tensor): [batch_size, ...x(N), D] Input features.
    Outputs:
        feats (torch.Tensor) [batch_size, ...x(N-1), D] Output features
    """

    length = attn_mask.sum(-1)
    mask_words = attn_mask.float() * (1 / (length.float().unsqueeze(-1).expand_as(attn_mask) + e))
    feats = feats * mask_words.unsqueeze(-1).expand_as(feats)
    feats = feats.sum(dim=-2)

    return feats
